-- ============================================
-- DATABASE: parcel_tracking_v2
-- FULL SCHEMA WITH FOREIGN KEY CONSTRAINTS
-- ============================================

DROP DATABASE IF EXISTS parcel_tracking_v2;
CREATE DATABASE parcel_tracking_v2;
USE parcel_tracking_v2;

-- ============================================
-- TABLE 1: admin
-- ============================================
CREATE TABLE admin (
    admin_id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    name VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- TABLE 2: warehouses
-- ============================================
CREATE TABLE warehouses (
    warehouse_id INT AUTO_INCREMENT PRIMARY KEY,
    city_name VARCHAR(100) NOT NULL UNIQUE,
    state_name VARCHAR(100) NOT NULL,
    latitude DECIMAL(10, 7) NOT NULL,
    longitude DECIMAL(10, 7) NOT NULL,
    address TEXT,
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- TABLE 3: agents
-- ============================================
CREATE TABLE agents (
    agent_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    phone VARCHAR(15) NOT NULL,
    warehouse_id INT NOT NULL,
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (warehouse_id) REFERENCES warehouses(warehouse_id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- TABLE 4: users
-- ============================================
CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    phone VARCHAR(15) NOT NULL,
    address TEXT NOT NULL,
    city VARCHAR(100),
    state VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- TABLE 5: parcels
-- ============================================
CREATE TABLE parcels (
    parcel_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    parcel_name VARCHAR(150) DEFAULT 'General Parcel',
    sender_address TEXT NOT NULL,
    receiver_address TEXT NOT NULL,
    weight DECIMAL(10, 2) NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    status VARCHAR(50) DEFAULT 'Booked',
    assigned_agent INT DEFAULT NULL,
    current_warehouse_id INT DEFAULT NULL,
    booking_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    delivery_date TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (assigned_agent) REFERENCES agents(agent_id) ON DELETE SET NULL ON UPDATE CASCADE,
    FOREIGN KEY (current_warehouse_id) REFERENCES warehouses(warehouse_id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- TABLE 6: parcel_location_history
-- ============================================
CREATE TABLE parcel_location_history (
    history_id INT AUTO_INCREMENT PRIMARY KEY,
    parcel_id INT NOT NULL,
    warehouse_id INT NOT NULL,
    status VARCHAR(50) NOT NULL,
    remarks TEXT,
    updated_by_agent INT DEFAULT NULL,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (parcel_id) REFERENCES parcels(parcel_id) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (warehouse_id) REFERENCES warehouses(warehouse_id) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (updated_by_agent) REFERENCES agents(agent_id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- TABLE 7: assignments
-- ============================================
CREATE TABLE assignments (
    assignment_id INT AUTO_INCREMENT PRIMARY KEY,
    parcel_id INT NOT NULL,
    agent_id INT NOT NULL,
    assigned_by_admin INT NOT NULL,
    assignment_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_active TINYINT(1) DEFAULT 1,
    FOREIGN KEY (parcel_id) REFERENCES parcels(parcel_id) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (agent_id) REFERENCES agents(agent_id) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (assigned_by_admin) REFERENCES admin(admin_id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- SAMPLE DATA - ADMIN
-- ============================================
INSERT INTO admin (email, password, name) VALUES 
('admin@smartcourier.com', 'admin123', 'Super Admin'),
('manager@smartcourier.com', 'manager123', 'System Manager');

-- ============================================
-- SAMPLE DATA - WAREHOUSES (34 Indian Cities)
-- ============================================
INSERT INTO warehouses (city_name, state_name, latitude, longitude, address, is_active) VALUES
('Mumbai', 'Maharashtra', 19.0760, 72.8777, 'SmartCourier Hub, Andheri East, Mumbai', 1),
('Delhi', 'Delhi', 28.7041, 77.1025, 'SmartCourier Hub, Connaught Place, New Delhi', 1),
('Bangalore', 'Karnataka', 12.9716, 77.5946, 'SmartCourier Hub, Whitefield, Bangalore', 1),
('Hyderabad', 'Telangana', 17.3850, 78.4867, 'SmartCourier Hub, HITEC City, Hyderabad', 1),
('Chennai', 'Tamil Nadu', 13.0827, 80.2707, 'SmartCourier Hub, Anna Nagar, Chennai', 1),
('Kolkata', 'West Bengal', 22.5726, 88.3639, 'SmartCourier Hub, Salt Lake, Kolkata', 1),
('Pune', 'Maharashtra', 18.5204, 73.8567, 'SmartCourier Hub, Hinjewadi, Pune', 1),
('Ahmedabad', 'Gujarat', 23.0225, 72.5714, 'SmartCourier Hub, Satellite, Ahmedabad', 1),
('Jaipur', 'Rajasthan', 26.9124, 75.7873, 'SmartCourier Hub, Mansarovar, Jaipur', 1),
('Surat', 'Gujarat', 21.1702, 72.8311, 'SmartCourier Hub, Adajan, Surat', 1),
('Lucknow', 'Uttar Pradesh', 26.8467, 80.9462, 'SmartCourier Hub, Gomti Nagar, Lucknow', 1),
('Kanpur', 'Uttar Pradesh', 26.4499, 80.3319, 'SmartCourier Hub, Swaroop Nagar, Kanpur', 1),
('Nagpur', 'Maharashtra', 21.1458, 79.0882, 'SmartCourier Hub, Sitabuldi, Nagpur', 1),
('Indore', 'Madhya Pradesh', 22.7196, 75.8577, 'SmartCourier Hub, Vijay Nagar, Indore', 1),
('Thane', 'Maharashtra', 19.2183, 72.9781, 'SmartCourier Hub, Ghodbunder Road, Thane', 1),
('Bhopal', 'Madhya Pradesh', 23.2599, 77.4126, 'SmartCourier Hub, Arera Colony, Bhopal', 1),
('Visakhapatnam', 'Andhra Pradesh', 17.6868, 83.2185, 'SmartCourier Hub, Madhurawada, Visakhapatnam', 1),
('Patna', 'Bihar', 25.5941, 85.1376, 'SmartCourier Hub, Boring Road, Patna', 1),
('Vadodara', 'Gujarat', 22.3072, 73.1812, 'SmartCourier Hub, Alkapuri, Vadodara', 1),
('Ghaziabad', 'Uttar Pradesh', 28.6692, 77.4538, 'SmartCourier Hub, Indirapuram, Ghaziabad', 1),
('Ludhiana', 'Punjab', 30.9010, 75.8573, 'SmartCourier Hub, Ferozepur Road, Ludhiana', 1),
('Agra', 'Uttar Pradesh', 27.1767, 78.0081, 'SmartCourier Hub, Sanjay Place, Agra', 1),
('Nashik', 'Maharashtra', 19.9975, 73.7898, 'SmartCourier Hub, College Road, Nashik', 1),
('Faridabad', 'Haryana', 28.4089, 77.3178, 'SmartCourier Hub, Sector 16, Faridabad', 1),
('Meerut', 'Uttar Pradesh', 28.9845, 77.7064, 'SmartCourier Hub, Shastri Nagar, Meerut', 1),
('Rajkot', 'Gujarat', 22.3039, 70.8022, 'SmartCourier Hub, Kalawad Road, Rajkot', 1),
('Varanasi', 'Uttar Pradesh', 25.3176, 82.9739, 'SmartCourier Hub, Sigra, Varanasi', 1),
('Srinagar', 'Jammu and Kashmir', 34.0837, 74.7973, 'SmartCourier Hub, Lal Chowk, Srinagar', 1),
('Amritsar', 'Punjab', 31.6340, 74.8723, 'SmartCourier Hub, Ranjit Avenue, Amritsar', 1),
('Chandigarh', 'Chandigarh', 30.7333, 76.7794, 'SmartCourier Hub, Sector 17, Chandigarh', 1),
('Coimbatore', 'Tamil Nadu', 11.0168, 76.9558, 'SmartCourier Hub, RS Puram, Coimbatore', 1),
('Kochi', 'Kerala', 9.9312, 76.2673, 'SmartCourier Hub, Edappally, Kochi', 1),
('Guwahati', 'Assam', 26.1445, 91.7362, 'SmartCourier Hub, Paltan Bazaar, Guwahati', 1),
('Bhubaneswar', 'Odisha', 20.2961, 85.8245, 'SmartCourier Hub, Kharavel Nagar, Bhubaneswar', 1);

-- ============================================
-- SAMPLE DATA - AGENTS
-- ============================================
INSERT INTO agents (name, email, password, phone, warehouse_id, is_active) VALUES
('Rajesh Kumar', 'rajesh@smartcourier.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '9876543210', 1, 1),
('Priya Sharma', 'priya@smartcourier.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '9876543211', 2, 1),
('Amit Patel', 'amit@smartcourier.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '9876543212', 3, 1),
('Sneha Reddy', 'sneha@smartcourier.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '9876543213', 4, 1),
('Vikram Singh', 'vikram@smartcourier.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '9876543214', 5, 1),
('Ananya Das', 'ananya@smartcourier.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '9876543215', 6, 1),
('Karan Mehta', 'karan@smartcourier.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '9876543216', 7, 1),
('Divya Joshi', 'divya@smartcourier.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '9876543217', 8, 1);

-- ============================================
-- SAMPLE DATA - USERS
-- ============================================
INSERT INTO users (name, email, password, phone, address, city, state) VALUES
('Arjun Verma', 'arjun@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '9123456780', '45, MG Road, Andheri', 'Mumbai', 'Maharashtra'),
('Meera Nair', 'meera@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '9123456781', '12, Nehru Place, Sector 5', 'Delhi', 'Delhi'),
('Rohan Gupta', 'rohan@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '9123456782', '78, Brigade Road, Koramangala', 'Bangalore', 'Karnataka'),
('Isha Kapoor', 'isha@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '9123456783', '22, Jubilee Hills, Banjara', 'Hyderabad', 'Telangana'),
('Sahil Agarwal', 'sahil@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '9123456784', '90, Mount Road, T Nagar', 'Chennai', 'Tamil Nadu');

-- ============================================
-- SAMPLE DATA - PARCELS
-- ============================================
INSERT INTO parcels (user_id, parcel_name, sender_address, receiver_address, weight, price, status, assigned_agent, current_warehouse_id, booking_date) VALUES
(1, 'Electronics Package', '45, MG Road, Andheri, Mumbai', '12, Nehru Place, Sector 5, Delhi', 5.5, 275, 'In Transit', 1, 2, '2025-11-10 09:30:00'),
(2, 'Documents', '12, Nehru Place, Delhi', '78, Brigade Road, Koramangala, Bangalore', 0.5, 25, 'Delivered', 2, 3, '2025-11-11 10:15:00'),
(3, 'Clothing Items', '78, Brigade Road, Bangalore', '22, Jubilee Hills, Hyderabad', 3.0, 150, 'In Transit', 3, 4, '2025-11-12 11:00:00'),
(4, 'Books Collection', '22, Jubilee Hills, Hyderabad', '90, Mount Road, Chennai', 8.0, 400, 'Booked', 4, 1, '2025-11-13 14:20:00'),
(5, 'Mobile Phone', '90, Mount Road, Chennai', '45, MG Road, Mumbai', 1.2, 60, 'Picked', 5, 5, '2025-11-14 08:45:00');

-- ============================================
-- SAMPLE DATA - PARCEL LOCATION HISTORY
-- ============================================
INSERT INTO parcel_location_history (parcel_id, warehouse_id, status, remarks, updated_by_agent, timestamp) VALUES
-- Parcel 1 journey: Mumbai -> Pune -> Delhi
(1, 1, 'Booked', 'Parcel received at Mumbai warehouse', 1, '2025-11-10 09:30:00'),
(1, 7, 'In Transit', 'Moved to Pune hub', 1, '2025-11-10 15:00:00'),
(1, 2, 'In Transit', 'Reached Delhi warehouse', 1, '2025-11-11 20:30:00'),

-- Parcel 2 journey: Delhi -> Bangalore (Delivered)
(2, 2, 'Booked', 'Parcel received at Delhi warehouse', 2, '2025-11-11 10:15:00'),
(2, 3, 'In Transit', 'Moved to Bangalore hub', 2, '2025-11-11 18:00:00'),
(2, 3, 'Delivered', 'Successfully delivered', 2, '2025-11-12 10:00:00'),

-- Parcel 3 journey: Bangalore -> Hyderabad
(3, 3, 'Booked', 'Parcel received at Bangalore warehouse', 3, '2025-11-12 11:00:00'),
(3, 4, 'In Transit', 'Reached Hyderabad warehouse', 3, '2025-11-13 09:00:00'),

-- Parcel 4 journey: Hyderabad (just booked)
(4, 1, 'Booked', 'Parcel booked and waiting for pickup', 4, '2025-11-13 14:20:00'),

-- Parcel 5 journey: Chennai (picked)
(5, 5, 'Booked', 'Parcel received at Chennai warehouse', 5, '2025-11-14 08:45:00'),
(5, 5, 'Picked', 'Parcel picked up by agent', 5, '2025-11-14 12:00:00');

-- ============================================
-- SAMPLE DATA - ASSIGNMENTS
-- ============================================
INSERT INTO assignments (parcel_id, agent_id, assigned_by_admin, assignment_date, is_active) VALUES
(1, 1, 1, '2025-11-10 09:35:00', 1),
(2, 2, 1, '2025-11-11 10:20:00', 1),
(3, 3, 1, '2025-11-12 11:05:00', 1),
(4, 4, 1, '2025-11-13 14:25:00', 1),
(5, 5, 1, '2025-11-14 08:50:00', 1);

-- ============================================
-- INDEXES FOR PERFORMANCE
-- ============================================
CREATE INDEX idx_parcels_user ON parcels(user_id);
CREATE INDEX idx_parcels_agent ON parcels(assigned_agent);
CREATE INDEX idx_parcels_warehouse ON parcels(current_warehouse_id);
CREATE INDEX idx_parcels_status ON parcels(status);
CREATE INDEX idx_history_parcel ON parcel_location_history(parcel_id);
CREATE INDEX idx_history_warehouse ON parcel_location_history(warehouse_id);
CREATE INDEX idx_assignments_parcel ON assignments(parcel_id);
CREATE INDEX idx_assignments_agent ON assignments(agent_id);

-- ============================================
-- DATABASE SETUP COMPLETE
-- ============================================
