-- ============================================
-- DATABASE VERIFICATION QUERIES
-- Run these after executing parcel_tracking_v2.sql
-- ============================================

USE parcel_tracking_v2;

-- Check if all tables exist
SELECT 'TABLES CREATED:' AS info;
SHOW TABLES;

-- Verify table structures
SELECT '---ADMIN TABLE---' AS info;
DESC admin;

SELECT '---WAREHOUSES TABLE---' AS info;
DESC warehouses;

SELECT '---AGENTS TABLE---' AS info;
DESC agents;

SELECT '---USERS TABLE---' AS info;
DESC users;

SELECT '---PARCELS TABLE---' AS info;
DESC parcels;

SELECT '---PARCEL_LOCATION_HISTORY TABLE---' AS info;
DESC parcel_location_history;

SELECT '---ASSIGNMENTS TABLE---' AS info;
DESC assignments;

-- Check record counts
SELECT 'RECORD COUNTS:' AS info;
SELECT 'Admin' AS table_name, COUNT(*) AS total_records FROM admin
UNION ALL
SELECT 'Warehouses', COUNT(*) FROM warehouses
UNION ALL
SELECT 'Agents', COUNT(*) FROM agents
UNION ALL
SELECT 'Users', COUNT(*) FROM users
UNION ALL
SELECT 'Parcels', COUNT(*) FROM parcels
UNION ALL
SELECT 'Parcel Location History', COUNT(*) FROM parcel_location_history
UNION ALL
SELECT 'Assignments', COUNT(*) FROM assignments;

-- Sample data preview
SELECT 'SAMPLE WAREHOUSES:' AS info;
SELECT warehouse_id, city_name, state_name, latitude, longitude FROM warehouses LIMIT 10;

SELECT 'SAMPLE AGENTS:' AS info;
SELECT a.agent_id, a.name, a.email, w.city_name AS warehouse_city 
FROM agents a
JOIN warehouses w ON a.warehouse_id = w.warehouse_id
LIMIT 5;

SELECT 'SAMPLE USERS:' AS info;
SELECT user_id, name, email, city, state FROM users LIMIT 5;

SELECT 'SAMPLE PARCELS WITH DETAILS:' AS info;
SELECT 
    p.parcel_id,
    p.parcel_name,
    u.name AS user_name,
    p.status,
    w.city_name AS current_location,
    a.name AS agent_name
FROM parcels p
LEFT JOIN users u ON p.user_id = u.user_id
LEFT JOIN warehouses w ON p.current_warehouse_id = w.warehouse_id
LEFT JOIN agents a ON p.assigned_agent = a.agent_id
LIMIT 5;

SELECT 'PARCEL LOCATION HISTORY SAMPLE:' AS info;
SELECT 
    plh.history_id,
    plh.parcel_id,
    w.city_name AS warehouse,
    plh.status,
    plh.remarks,
    plh.timestamp
FROM parcel_location_history plh
JOIN warehouses w ON plh.warehouse_id = w.warehouse_id
ORDER BY plh.parcel_id, plh.timestamp
LIMIT 15;

-- Foreign key relationships verification
SELECT 'FOREIGN KEY CONSTRAINTS:' AS info;
SELECT 
    TABLE_NAME,
    COLUMN_NAME,
    CONSTRAINT_NAME,
    REFERENCED_TABLE_NAME,
    REFERENCED_COLUMN_NAME
FROM
    INFORMATION_SCHEMA.KEY_COLUMN_USAGE
WHERE
    REFERENCED_TABLE_SCHEMA = 'parcel_tracking_v2'
    AND REFERENCED_TABLE_NAME IS NOT NULL;

SELECT 'DATABASE VERIFICATION COMPLETE!' AS info;
