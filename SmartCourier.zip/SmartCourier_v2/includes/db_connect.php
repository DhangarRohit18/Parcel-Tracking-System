<?php
// Database connection configuration
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "parcel_tracking_v2";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Database Connection Failed: " . $conn->connect_error);
}

// Set charset to UTF-8
$conn->set_charset("utf8mb4");
?>
